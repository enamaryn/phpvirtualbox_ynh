export VBOX_VERSION="5.2"
export VBOX_DOWNLOAD="https://download.virtualbox.org/virtualbox/5.2.6"
export VBOX_EXTPACK="Oracle_VM_VirtualBox_Extension_Pack-5.2.6-120293.vbox-extpack"
export VBOX_GUEST="VBoxGuestAdditions_5.2.6.iso"

